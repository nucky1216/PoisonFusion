def LeastQuare() :
	using the Gradiant decent to solve norm equation

def Cholsky2() :
	using the Cholsky decomposition to solve norm equation

def ClassicGramSchmidt():
	using Classic Gram-Schmidt to get the Q of QR decomposition

def ModifiedGramSchmidt():
	using Modified Gram-Schmidt to get the Q of QR decomposition